from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse

def start_test(request):
    return render(request, 'test/start_test.html')

def test_questions(request):
    # Logic to render questions
    return render(request, 'test/test_questions.html')

def test_results(request):
    # Logic to calculate and render results
    answers=request.session.get('answers',{})
    return render(request, 'test/test_results.html',{'answers':answers})

def process_answers(request):
    # Backend which takes the answers as POST request and feeds it to the model 
    if request.method== 'POST':
        question1_answer=request.POST.get('question_1')
        question2_answer=request.POST.get('question_2')

        print(f"Question 1 Answer: {question1_answer}")
        print(f"Question 2 Answer: {question2_answer}")
        
        answers={
            'question1':question1_answer,
            'question2':question2_answer,
        }

        return redirect('test_results')
    else:
        return HttpResponse("No data submitted")
    